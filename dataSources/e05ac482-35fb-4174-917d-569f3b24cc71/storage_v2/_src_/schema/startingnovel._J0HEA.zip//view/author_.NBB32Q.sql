create definer = root@localhost view author_ as
select `startingnovel`.`author`.`authorId`       AS `authorId`,
       `startingnovel`.`author`.`authorName`     AS `authorName`,
       `startingnovel`.`author`.`authorSynopsis` AS `authorSynopsis`
from `startingnovel`.`author`;

