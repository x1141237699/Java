create definer = root@localhost view bookclassification_ as
select `startingnovel`.`bookclassification`.`bookId`           AS `bookId`,
       `startingnovel`.`bookclassification`.`classificationId` AS `classificationId`
from `startingnovel`.`bookclassification`;

