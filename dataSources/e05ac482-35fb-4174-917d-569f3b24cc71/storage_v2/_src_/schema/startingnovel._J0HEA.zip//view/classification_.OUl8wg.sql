create definer = root@localhost view classification_ as
select `startingnovel`.`classification`.`classificationName` AS `classificationName`,
       `startingnovel`.`classification`.`classificationId`   AS `classificationId`
from `startingnovel`.`classification`;

