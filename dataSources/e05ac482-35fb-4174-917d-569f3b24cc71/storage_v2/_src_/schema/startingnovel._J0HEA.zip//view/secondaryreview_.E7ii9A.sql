create definer = root@localhost view secondaryreview_ as
select `startingnovel`.`secondaryreview`.`bookReviewId` AS `bookReviewId`,
       `startingnovel`.`secondaryreview`.`content`      AS `content`
from `startingnovel`.`secondaryreview`;

