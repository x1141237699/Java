create definer = root@localhost view publishedbook_ as
select `startingnovel`.`publishedbook`.`userAccount` AS `userAccount`,
       `startingnovel`.`publishedbook`.`bookId`      AS `bookId`
from `startingnovel`.`publishedbook`;

