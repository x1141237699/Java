create definer = root@localhost view history_ as
select `startingnovel`.`history`.`userAccount` AS `userAccount`,
       `startingnovel`.`history`.`bookId`      AS `bookId`,
       `startingnovel`.`history`.`date`        AS `date`
from `startingnovel`.`history`;

