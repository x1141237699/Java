create definer = root@localhost view bookcontent_ as
select `startingnovel`.`bookcontent`.`bookId` AS `bookId`, `startingnovel`.`bookcontent`.`content` AS `content`
from `startingnovel`.`bookcontent`;

