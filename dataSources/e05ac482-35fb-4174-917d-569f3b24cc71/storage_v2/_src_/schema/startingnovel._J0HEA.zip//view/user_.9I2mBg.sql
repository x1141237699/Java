create definer = root@localhost view user_ as
select `startingnovel`.`user`.`userName`     AS `userName`,
       `startingnovel`.`user`.`userAccount`  AS `userAccount`,
       `startingnovel`.`user`.`userPassword` AS `userPassword`
from `startingnovel`.`user`;

