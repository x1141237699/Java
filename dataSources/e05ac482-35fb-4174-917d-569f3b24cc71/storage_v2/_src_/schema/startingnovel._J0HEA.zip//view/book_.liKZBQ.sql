create definer = root@localhost view book_ as
select `startingnovel`.`book`.`bookName`   AS `bookName`,
       `startingnovel`.`book`.`bookId`     AS `bookId`,
       `startingnovel`.`book`.`bookPage`   AS `bookPage`,
       `startingnovel`.`book`.`authorName` AS `authorName`,
       `startingnovel`.`book`.`synopsis`   AS `synopsis`,
       `startingnovel`.`book`.`updateTime` AS `updateTime`,
       `startingnovel`.`book`.`catalogue`  AS `catalogue`
from `startingnovel`.`book`;

