create definer = root@localhost view likedbook_ as
select `startingnovel`.`likedbook`.`userAccount` AS `userAccount`, `startingnovel`.`likedbook`.`bookId` AS `bookId`
from `startingnovel`.`likedbook`;

