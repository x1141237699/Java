create definer = root@localhost view hotlist_ as
select `startingnovel`.`hotlist`.`bookId` AS `bookId`, `startingnovel`.`hotlist`.`rank` AS `rank`
from `startingnovel`.`hotlist`;

