create definer = root@localhost view bookkeyword_ as
select `startingnovel`.`bookkeyword`.`bookId` AS `bookId`, `startingnovel`.`bookkeyword`.`keywordId` AS `keywordId`
from `startingnovel`.`bookkeyword`;

