create definer = root@localhost view keyword_ as
select `startingnovel`.`keyword`.`keywordId` AS `keywordId`, `startingnovel`.`keyword`.`content` AS `content`
from `startingnovel`.`keyword`;

