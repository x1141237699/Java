create definer = root@localhost view wantedbook_ as
select `startingnovel`.`wantedbook`.`userAccount` AS `userAccount`, `startingnovel`.`wantedbook`.`bookId` AS `bookId`
from `startingnovel`.`wantedbook`;

