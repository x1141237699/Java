create definer = root@localhost view bookreview_ as
select `startingnovel`.`bookreview`.`bookId`       AS `bookId`,
       `startingnovel`.`bookreview`.`bookReviewId` AS `bookReviewId`,
       `startingnovel`.`bookreview`.`content`      AS `content`
from `startingnovel`.`bookreview`;

