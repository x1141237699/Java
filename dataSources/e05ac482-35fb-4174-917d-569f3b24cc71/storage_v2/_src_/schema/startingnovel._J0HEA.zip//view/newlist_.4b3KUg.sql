create definer = root@localhost view newlist_ as
select `startingnovel`.`newlist`.`bookId` AS `bookId`, `startingnovel`.`newlist`.`rank` AS `rank`
from `startingnovel`.`newlist`;

